Fe5Ni8 Gupta energy landscape — downloadable data
=================================================

Units
  Energies in the XYZ comment lines are in eV.
  Barriers in the transition-state XYZ comment lines are in kcal/mol,
  using 1 eV = 23.06054783 kcal/mol.
  Coordinates are Cartesian, in angstrom.

Composition
  13 atoms, Fe5Ni8.

Geometries
  All XYZ coordinates are Gupta-potential stationary points from ABCluster
  and ASE climbing-image NEB. They are NOT PBE-relaxed.

  Fe5Ni8_minima_connected.xyz
    The 212 connected minima, sorted by Gupta energy. The global minimum
    (uid 0) has energy -38.09476246 eV. Each comment line gives the energy,
    uid, and family code/name.

  Fe5Ni8_minima_all_unique.xyz
    All 999 unique Gupta minima (the 212 connected ones plus 787
    unconnected isolates). This is not the connected set used in the
    landscape figures.

  Fe5Ni8_transition_states.xyz
    The 307 clean transition-state geometries that join two connected
    minima. A saddle is clean if it converged, has exactly one negative
    Hessian mode, and satisfies E_TS >= max(E_start, E_end) - 1e-4 eV.
    Each comment line gives the TS tag, the two endpoint uids, E_TS in eV,
    and both barriers in kcal/mol (from the lower and the higher endpoint).
    Barriers from the lower minimum in this set range from 1.80 to 63.34 kcal/mol.

  Fe5Ni8_connections.csv
    One row per clean transition state: endpoint uids and families, endpoint
    and TS energies (eV), both barriers (kcal/mol), NEB pass, endpoint RMSD.

Gaussian 16 inputs (Fe5Ni8_gjf.zip)
  One .gjf file per connected minimum (minima/) and per clean TS (ts/).
  These are PBEPBE / Stuttgart RSC 1997 ECP single-point jobs built from
  the same SPC template as Fe4Ni9 (GEN PSEUDO=READ, UltraFine integrals,
  SCF=(XQC,Tight,MaxCycle=1024) Guess=Mix 5D 7F), charge 0, multiplicity 21.
  The multiplicity is NOT from a spin scan: it scales the Fe4Ni9 choice
  (19, i.e. 18 unpaired = 4 x 3 + 9 x 0.67) to 5 x 3 + 8 x 0.67 = 20.4,
  rounded to the nearest even unpaired count (20). Check it with a spin scan.
  They are single points, not optimizations. The geometries inside are
  the same Gupta coordinates as in the XYZ files, not PBE-relaxed.

Figures
  Fe5Ni8_connectivity_circular.pdf  — circular connectivity by family (10 families)
                                      with a black disc, as on the metal cards
  Fe5Ni8_disconnectivity.pdf        — disconnectivity graph of the
                                      212 connected minima (PDF only)

Fe13 Gupta energy landscape — downloadable data
=================================================

Units
  Energies in the XYZ comment lines are in eV.
  Barriers in the transition-state XYZ comment lines are in kcal/mol,
  using 1 eV = 23.06054783 kcal/mol.
  Coordinates are Cartesian, in angstrom.

Composition
  13 atoms, Fe13.

Geometries
  All XYZ coordinates are Gupta-potential stationary points from ABCluster
  and ASE climbing-image NEB. They are NOT PBE-relaxed.

  Fe13_minima_connected.xyz
    The 171 connected minima, sorted by Gupta energy. The global minimum
    (uid 0) has energy -42.55265740 eV. Each comment line gives the energy,
    uid, and family code/name.

  Fe13_minima_all_unique.xyz
    All 380 unique Gupta minima (the 171 connected ones plus 209
    unconnected isolates). This is not the connected set used in the
    landscape figures.

  Fe13_transition_states.xyz
    The 318 clean transition-state geometries that join two connected
    minima. A saddle is clean if it converged, has exactly one negative
    Hessian mode, and satisfies E_TS >= max(E_start, E_end) - 1e-4 eV.
    Each comment line gives the TS tag, the two endpoint uids, E_TS in eV,
    and both barriers in kcal/mol (from the lower and the higher endpoint).
    Barriers from the lower minimum in this set range from 0.20 to 41.45 kcal/mol.

  Fe13_connections.csv
    One row per clean transition state: endpoint uids and families, endpoint
    and TS energies (eV), both barriers (kcal/mol), NEB pass, endpoint RMSD.

Gaussian 16 inputs (Fe13_gjf.zip)
  One .gjf file per connected minimum (minima/) and per clean TS (ts/).
  These are PBEPBE / Stuttgart RSC 1997 ECP single-point jobs built from
  the same SPC template as Fe4Ni9 (GEN PSEUDO=READ, UltraFine integrals,
  SCF=(XQC,Tight,MaxCycle=1024) Guess=Mix 5D 7F), charge 0, multiplicity 41.
  The multiplicity is NOT from a spin scan: it uses the same high-spin
  estimate as the mixed Fe-Ni cards (3 unpaired per Fe), giving 13 x 3 = 39.
  Fe13 has an even electron count, so the unpaired count must be even; 39 is
  halfway between 38 and 40, and we take the high-spin side (40), 2S+1 = 41.
  Check it with a spin scan.
  They are single points, not optimizations. The geometries inside are
  the same Gupta coordinates as in the XYZ files, not PBE-relaxed.

Figures
  Fe13_connectivity_circular.pdf  — circular connectivity by family (3 families)
                                      with a black disc, as on the metal cards
  Fe13_disconnectivity.pdf        — disconnectivity graph of the
                                      171 connected minima (PDF only)

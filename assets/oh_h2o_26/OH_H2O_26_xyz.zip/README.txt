OH-(H2O)26 energy landscape
TIP4P/2005 water + Madrid-2019 compatible OH- (de Lucas 2024)
ABCluster 3.4 rigidmol, native arm64, MacBook Air (Apple M1)
Work is confined to this directory. Website is not touched by the compute job.

Force field (gas-phase cluster, no counterion, net charge -0.85 e)
  Water: TIP4P/2005, Abascal & Vega, J. Chem. Phys. 123, 234505 (2005).
    OW sigma=3.15890 A, eps=0.774900 kJ/mol, charge 0
    HW charge +0.5564, sigma=0, eps=0
    MW virtual charge -1.1128, sigma=0, eps=0
    d(OH)=0.9572 A, d(HH)=1.5139 A; virtual M from O,H1,H2 with a=b=0.13193828
  OH-: Madrid-2019 compatible hydroxide, de Lucas 2024 (topology as provided).
    O charge -1.0727, physical sigma=3.40000 A, eps=0.250891 kJ/mol
    H charge +0.2227, sigma=1.44300 A, eps=0.183909 kJ/mol
    rigid r(OH)=0.9800 A
  Mixing: Lorentz-Berthelot, except the Madrid-2019 O_OH-O_W override
    sigma=3.45000 A, eps=0.440926 kJ/mol
  The ABCluster OH parameter file uses an effective oxygen sigma of 3.74110 A so that
  Lorentz-Berthelot with TIP4P/2005 OW reproduces that override. There is only one
  hydroxide, so the O_OH-O_OH self term is never used. The Python calculator uses the
  physical sigma and the explicit override. The two agree on the (H2O)2 and OH-(H2O)
  dimers (residuals 6e-7 and 1e-5 kJ/mol). Coulomb constant: 332.1 kcal A/mol (as in
  ABCluster), converted with 4.184 to kJ/mol.

Search
  SN=100, gmax=2000, glimit=10, L=12.0 A, nLM=1000
  caffeinate -is nice -n 10, OMP_NUM_THREADS=8

Saddles
  Rigid-body CI-NEB, P-RFO refinement, unit-mass Hessian with the six global modes
  and the OH spin projected out. Only the global-minimum-connected component is plotted.
  Lowest saddle kept per pair. No inferred links. Clean TS: one imaginary mode,
  connected by downhill relaxation.

Families
  Assigned from the geometries: OH- location (interior vs surface, convex hull of
  oxygens), coordination number of water oxygens about O_OH within 3.40 A, and
  oxygen packing (cubic / fused-cubic / other) from a 3x3x3 lattice fit and
  four-membered oxygen rings. Families that do not appear are not reported.

Gaussian 16 inputs
  Route taken from the existing water-cluster template
  /Users/kono/work/NaCl_nH2O/Oct19/M062X_aVDZ_to_aVTZ_NaCl_4H2O_OPT_FREQ_iso1INP.GJF
    #P M062X/aug-cc-pVDZ Opt Freq Scale=0.979 SCF=Tight SCFCyc=500 OptCyc=500
  Charge and multiplicity -1 1 (quantum-chemical hydroxide). The classical model
  charge is -0.85 e. %NprocShared, %Mem, %Chk and the Link1 aVTZ continuation were
  not copied.

Key paths
  Force field:     ff/tip4p2005.xyz  ff/oh_madrid2019.xyz
  Verification:    verify/  (OK when the dimer check passed)
  Main search:     run_main/
  Analysis:        analysis/
  Saddles, plots:  saddles/
  Zips:            zips/OH_H2O_26_xyz.zip  zips/OH_H2O_26_gjf.zip  zips/OH_H2O_26_pdf.zip
  Scripts:         landscape/

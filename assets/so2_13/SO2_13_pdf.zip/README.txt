(SO2)13 energy landscape - Sokolic rigid SO2 force field
=========================================================
Force field: Sokolic & Guissani, Croat. Chem. Acta 59 (1986) 695; see also Sokolic, Guissani & Guillot, J. Phys. Chem. 1985, doi:10.1021/j100260a021;
Model C (three-site Lennard-Jones + fractional charges), Table V parameter set 1 (fitted at 220 K).
  rigid SO2: r(S-O) = 1.4343 A, angle(O-S-O) = 119.5 deg
  eps_SS/kB = 155.5 K (1.29290 kJ/mol), sigma_SS = 3.575 A
  eps_OO/kB = 63.2 K (0.52547 kJ/mol),  sigma_OO = 2.988 A
  Lorentz-Berthelot mixing for S-O; q_S = +0.470 e, q_O = -0.235 e (from 7.53e-20 C)
  Coulomb constant 332.1 kcal A/mol (x 4.184), as used by ABCluster. Energies in kJ/mol.
Global optimisation: ABCluster 3.4 rigidmol (Zhang & Dolg, PCCP 2015, 17, 24173; PCCP 2016, 18, 3003),
  population 100, 2000 generations, scout limit 10, amplitude 8 A, 1000 local minima saved.
Saddles: rigid-body climbing-image NEB (projected forces, FIRE), P-RFO refinement in rigid-body coordinates,
  rigid-body Hessian (6 global zero modes projected out), downhill minimisation along the imaginary mode
  on both sides to identify the two minima each transition state actually connects.
  Clean TS: NEB converged, P-RFO converged, exactly one imaginary mode, both downhill endpoints true minima.
Global minimum: -231.75679 kJ/mol (centred icosahedral S skeleton: 1 interior SO2 + 12 in the shell).
GM-connected component: 201 minima, 243 clean transition states.
Families on the ring: centred_Ih 143, distorted_Ih 56, other_1interior 1, decahedral-like 1.
Barrier (from the lower minimum): 0.08-7.59 kJ/mol (0.02-1.81 kcal/mol).
Files: connected_minima.xyz, transition_states_connected.xyz (multi-frame; comment lines carry uid/family/energy),
  connections.csv (one row per connected pair, lowest TS), summary.json.
Gaussian inputs (SO2_13_gjf.zip): route copied from the author's template as is; not run.
